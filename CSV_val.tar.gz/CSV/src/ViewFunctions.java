import java.util.ArrayList;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;


public class ViewFunctions {
	
	void tidyView(final JTextArea editorPane){
		

		
		String record = "", value = "", errorText = "", text = editorPane.getText(), newText = "";
		char quote = '\"', delimiter  = ',', endLine = '\n', space = ' ';
		
		boolean pre_escape = false, openQuote = false, begin_field = true;
		
		int errorCounter = 0,  recBegin = 1, currentLine = 1, openQuotePosition = 0;
		
		ArrayList<String> values = new  ArrayList<String>();
		
		
		for( char c : text.toCharArray() ){
		
			record += c;
			value += c;
			
			
			
			if( c == delimiter ){
				if( !openQuote && !begin_field && !pre_escape ){
					begin_field = true;
					
					newText +='\t';
					
					values.add(value);
					value = "";
				}
				else if( !openQuote && begin_field && !pre_escape ){
					
					newText +='\t';
					
					values.add(value);
					value = "";
					
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					newText +=c;
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					openQuote = false;
					begin_field = true;
					pre_escape = false;
					
					newText +='\t';
					
					values.add(value);
					value = "";
										
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
					
				}
			}
			else if( c ==  endLine){
				newText += c;
				if( !openQuote && !begin_field && !pre_escape ){
					begin_field = true;
					
					
					
					
					values.add(value);					//Add the last value since it will not have end delimiter
					
					value = "";
					record = "";
					recBegin = currentLine + 1;
					values.clear();
		
				}
				else if( !openQuote && begin_field && !pre_escape ){
					
					values.add(value);					//Add the last value since it will not have end delimiter
					
					
					
					value = "";
					record = "";
					recBegin = currentLine + 1;
					values.clear();
					
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					openQuote = false;
					begin_field = true;
					pre_escape = false;
					
					values.add(value);					//Add the last value since it will not have end delimiter
					
		
					value = "";
					record = "";
					recBegin = currentLine + 1;
					values.clear();
					
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
				}
				
				currentLine++;
				
			}
			else if( c ==  space ){
				newText += c;
				if( !openQuote && !begin_field && !pre_escape ){
					
				}
				else if( !openQuote && begin_field && !pre_escape ){
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					pre_escape = false;
					errorText +=  "\n\n"+ ++errorCounter +": UNESCAPE QUOTE:   at line " +(currentLine);
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
				}
			}
			else if( c == quote ){
				newText += c;
				if( !openQuote && !begin_field && !pre_escape ){
					
					errorText +=  "\n\n"+ ++errorCounter +": UNENCLOSED QUOTE: at line " +(currentLine);
					
				}
				else if( !openQuote && begin_field && !pre_escape ){
					
					openQuote = true;
					openQuotePosition =  currentLine;
					
					begin_field = false;
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					pre_escape = true; 
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					pre_escape = false;
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
				}
			}
			else{
				
				newText += c;
				if( !openQuote && !begin_field && !pre_escape ){
					
				}
				else if( !openQuote && begin_field && !pre_escape ){
					
					begin_field = false; 
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					pre_escape = false;
					errorText +=  "\n\n"+ ++errorCounter +": UNESCAPE QUOTE:   at line " +(currentLine);
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
				}
			}
			
		}
		
		
		
		
		// Add the last record since it may not have endline character
		values.add(value);
												
		editorPane.setText(newText);	
		
		
	}
	
	
	void commaView(final JTextArea editorPane){
		

		
		String record = "", value = "", errorText = "", text = editorPane.getText(), newText = "";
		char quote = '\"', delimiter  = '\t', endLine = '\n', space = ' ';
		
		boolean pre_escape = false, openQuote = false, begin_field = true;
		
		int errorCounter = 0,  recBegin = 1, currentLine = 1, openQuotePosition = 0;
		
		ArrayList<String> values = new  ArrayList<String>();
		
		
		for( char c : text.toCharArray() ){
		
			record += c;
			value += c;
			
			
			
			if( c == delimiter ){
				if( !openQuote && !begin_field && !pre_escape ){
					begin_field = true;
					
					newText +=',';
					
					values.add(value);
					value = "";
				}
				else if( !openQuote && begin_field && !pre_escape ){
					
					newText +=',';
					
					values.add(value);
					value = "";
					
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					newText += c;
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					openQuote = false;
					begin_field = true;
					pre_escape = false;
					
					newText +=',';
					
					values.add(value);
					value = "";
										
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
					
				}
			}
			else if( c ==  endLine){
				newText += c;
				if( !openQuote && !begin_field && !pre_escape ){
					begin_field = true;
					
					
					
					
					values.add(value);					//Add the last value since it will not have end delimiter
					
					value = "";
					record = "";
					recBegin = currentLine + 1;
					values.clear();
		
				}
				else if( !openQuote && begin_field && !pre_escape ){
					
					values.add(value);					//Add the last value since it will not have end delimiter
					
					
					
					value = "";
					record = "";
					recBegin = currentLine + 1;
					values.clear();
					
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					openQuote = false;
					begin_field = true;
					pre_escape = false;
					
					values.add(value);					//Add the last value since it will not have end delimiter
					
		
					value = "";
					record = "";
					recBegin = currentLine + 1;
					values.clear();
					
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
				}
				
				currentLine++;
				
			}
			else if( c ==  space ){
				newText += c;
				if( !openQuote && !begin_field && !pre_escape ){
					
				}
				else if( !openQuote && begin_field && !pre_escape ){
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					pre_escape = false;
					errorText +=  "\n\n"+ ++errorCounter +": UNESCAPE QUOTE:   at line " +(currentLine);
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
				}
			}
			else if( c == quote ){
				newText += c;
				if( !openQuote && !begin_field && !pre_escape ){
					
					errorText +=  "\n\n"+ ++errorCounter +": UNENCLOSED QUOTE: at line " +(currentLine);
					
				}
				else if( !openQuote && begin_field && !pre_escape ){
					
					openQuote = true;
					openQuotePosition =  currentLine;
					
					begin_field = false;
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					pre_escape = true; 
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					pre_escape = false;
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
				}
			}
			else{
				
				newText += c;
				if( !openQuote && !begin_field && !pre_escape ){
					
				}
				else if( !openQuote && begin_field && !pre_escape ){
					
					begin_field = false; 
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					pre_escape = false;
					errorText +=  "\n\n"+ ++errorCounter +": UNESCAPE QUOTE:   at line " +(currentLine);
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
				}
			}
			
		}
		// Add the last record since it may not have endline character
		values.add(value);
												
		editorPane.setText(newText);	
	}
	
	

}
