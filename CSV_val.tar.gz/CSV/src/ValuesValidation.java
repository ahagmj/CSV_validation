import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;


public class ValuesValidation {
	
	
	JTextArea editorPane;
	public HashMap<Integer, String> mapRecordtoLine;
	ArrayList<String> arrangeRecord = new  ArrayList<String>();
	String  errors = "", dataText = "";
//	final Highlighter highlighter;
//	final Highlighter.HighlightPainter highlightPainter1, highlightPainter2;
	static boolean alternateColours = false;
	int headerLength, index = 0, p = 0, startline;
	String[] schema;
//	HighlighterClass phighlighter;
	
	
	//String  errortxt, warningtxt, suggestiontxt;
	
	
	ValuesValidation( JTextArea textArea  ){
		 editorPane = textArea;
		
		
	}
	
	
	//Functions implementation,
	int headerSize(){
		
		dataText = editorPane.getText();
		
		int fieldsCount = 0;
		String header;
		
		if(  ( JOptionPane.showConfirmDialog(null, "Is the first line header ?", "Verify Header", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE)== 0 )) 
		 {
			header = dataText.split("\n")[0];
			fieldsCount =  header.split(",").length;
			dataText = dataText.replaceFirst(header+"\n", "");
			p = header.length()+1;
			startline = 2;
		//	recordCounter = 1;   								 // First line has been removed, record start form second line
		 }
		else{
			 
			String noOfFields = JOptionPane.showInputDialog(editorPane, "Please how many fields are in the data ?", "Number of fields", JOptionPane.QUESTION_MESSAGE);
			
			// TO DO HERE; Detect empty   
			// Detect cancel   
			
			//System.out.print(" no of fields is :"+ noOfFields);
							
			try{ fieldsCount = Integer.parseInt(noOfFields); }				
			catch(NumberFormatException ex){
				
				//  To catch empty and null
				JOptionPane.showMessageDialog(editorPane, "Unrecognised input", "INPUT ERROR", JOptionPane.ERROR_MESSAGE);
							
				}
		//	recordCounter = 1;   								 // record start from first line
			startline = 1;
			
		 } 
		
		return fieldsCount;
		
	}
	
	public boolean validate(JTextArea display, JTextArea warningtxt, JTextArea suggestiontxt, HighlighterClass highlighterArg){
		
		
		if(editorPane.getText().isEmpty()){
			JOptionPane.showMessageDialog(editorPane, "The text editor has nothing to validate.", "Caution", JOptionPane.INFORMATION_MESSAGE);
			return false;
		}
			// Not empty
		else{
			
			headerLength = headerSize();
			if(headerLength < 0){
				JOptionPane.showMessageDialog(editorPane, " Negative is an inavalid header length.\nThe process has been terminated", "INVALID HEADER LENGHT", JOptionPane.ERROR_MESSAGE);
				return false;
			}
			mapRecordtoLine =  new  HashMap<Integer, String>();
			mapRecordtoLine.put(0, 1+" to "+1);										//Initialise for the first record to take care of null for firstline error
			
			if(!((schema = validateSchema(display)) == null) ){
			
			parse(dataText, schema, highlighterArg, startline );
			display.setText( ">>>Errors :\n" + errors);
			
			}
		}
		
		if(errors.isEmpty()){
			return true; }
		else{
			return false;		}
	}


	String[] parse( String text, String[] schema, HighlighterClass phighlighterArg, int linesBegin){
		
		
		String record = "", value = "", errorText = "";
		char quote = '\"', delimiter  = ',', endLine = '\n', space = ' ';
		
		boolean pre_escape = false, openQuote = false, begin_field = true, detectError = false;
		
		int errorCounter = 1,  recBegin = linesBegin, currentLine = linesBegin, openQuotePosition = 0, fieldNo = 0,  recordCounter = 1;
		
		ArrayList<String> values = new  ArrayList<String>();
		
		phighlighterArg.removeHighlight();     // Remove previous highlight if it exist.
				
		for( char c : text.toCharArray() ){
		
			record += c;
			p++;
			
			if( c == delimiter ){
				if( !openQuote && !begin_field && !pre_escape ){
					begin_field = true;
					
					
					if(! validateFieldValue( value, schema[ schemaBound(fieldNo) ]  )){
						phighlighterArg.highlight(value, p);
						//errorText += "\nIn record "+a+" that span line "+ validatorObject.mapRecordtoLine.get(a)+ " field "+(b+1) + " has invalid data";
						errorText +=  "\n\n"+ ++errorCounter +": INVALID "+schema[fieldNo] +":   at line " +(currentLine) + " inside record "+
						+recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine);
					}
						
					fieldNo++;
					
					values.add(value);
					value = "";
				}
				else if( !openQuote && begin_field && !pre_escape ){
					
					if(! validateFieldValue( value, schema[ schemaBound(fieldNo) ]  )){
						phighlighterArg.highlight(value, p);
						//errorText += "\nIn record "+a+" that span line "+ validatorObject.mapRecordtoLine.get(a)+ " field "+(b+1) + " has invalid data";
						errorText +=  "\n\n"+ ++errorCounter +": INVALID "+schema[fieldNo] +":   at line " +(currentLine) + " inside record "+
						+recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine);
					}
					fieldNo++;
					
					values.add(value);
					value = "";
				}
				else if( openQuote && !begin_field && !pre_escape ){
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					openQuote = false;
					begin_field = true;
					pre_escape = false;
					
					value = removeClosingQuote(value);
					
					if(! validateFieldValue( value, schema[ schemaBound(fieldNo) ]  )){
						phighlighterArg.highlight(value, p);
						//errorText += "\nIn record "+a+" that span line "+ validatorObject.mapRecordtoLine.get(a)+ " field "+(b+1) + " has invalid data";
						errorText +=  "\n\n"+ ++errorCounter +": INVALID "+schema[fieldNo] +":   at line " +(currentLine) + " inside record "+
						+recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine);
					}					
					fieldNo++;
					
					values.add(value);
					value = "";
										
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
					
				}
			}
			else if( c ==  endLine){
				
				if( !openQuote && !begin_field && !pre_escape ){
					begin_field = true;
					
					if(! validateFieldValue( value, schema[ schemaBound(fieldNo) ]  )){
						phighlighterArg.highlight(value, p);
						errorText +=  "\n\n"+ ++errorCounter +": INVALID "+schema[fieldNo] +":   at line " +(currentLine) + " inside record "+
						+recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine)+"\n value = "+value;
					}
					fieldNo++;
					values.add(value);					//Add the last value since it will not have end delimiter
					
													
					if(values.size() < headerLength ){
						errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has less than the required data";
						detectError = true;
					}
					else if(values.size() > headerLength ){
						errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has more than the expected data";
						detectError = true;
					}

					arrangeRecord.add(record);				//Add a record
					mapRecordtoLine.put(recordCounter, (recBegin)+" to "+(currentLine));
					recordCounter++;
					
					
					if(detectError){
						phighlighterArg.highlight(record, p);
						detectError = false;
					}
					value = "";
					record = "";
					recBegin = currentLine + 1;
					values.clear();
					fieldNo = 0;
		
				}
				else if( !openQuote && begin_field && !pre_escape ){
					
					if(! validateFieldValue( value, schema[ schemaBound(fieldNo) ]  )){
						phighlighterArg.highlight(value, p);
						//errorText += "\nIn record "+a+" that span line "+ validatorObject.mapRecordtoLine.get(a)+ " field "+(b+1) + " has invalid data";
						errorText +=  "\n\n"+ ++errorCounter +": INVALID "+schema[fieldNo] +":   at line " +(currentLine) + " inside record "+
						+recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine);
					}
										
					fieldNo++;
					values.add(value);					//Add the last value since it will not have end delimiter
					
					
								
					if(values.size() < headerLength ){
						errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has less than the required data";
						detectError = true;
					}
					else if(values.size() > headerLength ){
						errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has more than the expected data";
						detectError = true;
					}
					
					arrangeRecord.add(record);				//Add a record
					mapRecordtoLine.put(recordCounter, (recBegin)+" to "+(currentLine));
					recordCounter++;
										
					if(detectError){
						phighlighterArg.highlight(record, p);
						detectError = false;
					}
					
					value = "";
					record = "";
					recBegin = currentLine + 1;
					values.clear();
					fieldNo = 0;
					
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					openQuote = false;
					begin_field = true;
					pre_escape = false;
					
					//value += c;
					value = removeClosingQuote(value);
										
					if(! validateFieldValue( value, schema[ schemaBound(fieldNo) ]  )){
						phighlighterArg.highlight(value, p);
						//errorText += "\nIn record "+a+" that span line "+ validatorObject.mapRecordtoLine.get(a)+ " field "+(b+1) + " has invalid data";
						errorText +=  "\n\n"+ ++errorCounter +": INVALID "+schema[fieldNo] +":   at line " +(currentLine) + " inside record "+
						+recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine);
					}
					fieldNo++;
					values.add(value);					//Add the last value since it will not have end delimiter
					
					
								
					if(values.size() < headerLength ){
						errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has less than the required data";
						detectError = true;
					}
					else if(values.size() > headerLength ){
						errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has more than the expected data";
						detectError = true;
					}
					
					arrangeRecord.add(record);				//Add a record
					mapRecordtoLine.put(recordCounter, (recBegin)+" to "+(currentLine));
					recordCounter++;
					
					if(detectError){
						phighlighterArg.highlight(record, p);
						detectError = false;
					}
					
					value = "";
					record = "";
					recBegin = currentLine + 1;
					values.clear();
					fieldNo = 0;
					
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
				}
				
				currentLine+=1;
			}
			else if( c ==  space ){
				value += c;
				if( !openQuote && !begin_field && !pre_escape ){
					
				}
				else if( !openQuote && begin_field && !pre_escape ){
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					pre_escape = false;
					errorText +=  "\n\n"+ ++errorCounter +": UNESCAPE QUOTE:   at line " +(currentLine);
					detectError = true;
					
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
				}
			}
			else if( c == quote ){
				
				if( !openQuote && !begin_field && !pre_escape ){
					
					errorText +=  "\n\n"+ ++errorCounter +": UNENCLOSED QUOTE: at line " +(currentLine);
					detectError = true;
					value += c;
					
				}
				else if( !openQuote && begin_field && !pre_escape ){
					
					openQuote = true;
					openQuotePosition =  currentLine;
					
					begin_field = false;
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					pre_escape = true;
					value += c;
				}
				else if( openQuote && !begin_field && pre_escape ){
					pre_escape = false;
					value += c;
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
				}
			}
			else{
				value += c;
				if( !openQuote && !begin_field && !pre_escape ){
					
				}
				else if( !openQuote && begin_field && !pre_escape ){
					
					begin_field = false; 
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					pre_escape = false;
					errorText +=  "\n\n"+ ++errorCounter +": UNESCAPE QUOTE:   at line " +(currentLine);
					detectError = true;
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
				}
			}
			
		}
		
		
		
		
		// Add the last record since it may not have endline character
		
		value = removeClosingQuote(value);
		if(! validateFieldValue( value, schema[ schemaBound(fieldNo) ]  )){
			phighlighterArg.highlight(value, p);
			//errorText += "\nIn record "+a+" that span line "+ validatorObject.mapRecordtoLine.get(a)+ " field "+(b+1) + " has invalid data";
			errorText +=  "\n\n"+ ++errorCounter +": INVALID "+schema[fieldNo] +":   at line " +(currentLine) + " inside record "+
			+recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine);
		}		
		fieldNo++;
		values.add(value);
												
		
	
		
		if(values.size() < headerLength ){
			errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has less than the required data"; 					
			detectError = true;
			}
		else if(values.size() > headerLength ){
			errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has more than the expected data"; 					
			detectError = true;
			//highlight( record);
		}
		
		arrangeRecord.add(record);
		mapRecordtoLine.put(recordCounter, (recBegin)+" to "+(currentLine));
		recordCounter++;
		
		if(openQuote && !pre_escape ){
			errorText +=  "\n\n"+ ++errorCounter +": UNCLOSE OPEN QUOTE :  at line " +(openQuotePosition);
			detectError = true;
			//highlight(record);
		}
		if(detectError){
			phighlighterArg.highlight(record, p);
			detectError = false;
		}
		
		
	// Completed, assign the errors for display and return the records.	
		
		errors = errorText;
		return	 arrangeRecord.toArray(new String[arrangeRecord.size()]);
    }
	
	
	
	// Function for validating the schema
	public String[] validateSchema(JTextArea textArea) {
		final JFileChooser fileChooserObject = new JFileChooser(); 
		BufferedReader bufferedReader ;
		String schema, s;
		String[] typeRead, correctType = new String[4] ;
		String schemaError =  "";
		
			JOptionPane.showMessageDialog(null, "Please locate a schema file", "SCHEMA FILE", JOptionPane.INFORMATION_MESSAGE);
			if( fileChooserObject.showOpenDialog(null) == JFileChooser.APPROVE_OPTION){
					//editorPane.setText("");
				
					File file = fileChooserObject.getSelectedFile();
						try {
							bufferedReader = new BufferedReader( new FileReader(file));
							
								if((schema = bufferedReader.readLine()) != null){
									typeRead = schema.split(",");
									
									
									int header = typeRead.length ;     //REPRESENT HEADER LENGTH       SHOULD BE CORRECTED???????????????????
									if( (typeRead.length < header) ){
										JOptionPane.showMessageDialog(null, "Incomplete schema", "Schema Error", JOptionPane.ERROR_MESSAGE);
									}
									else if( (typeRead.length > header) ){
										JOptionPane.showMessageDialog(null, "Schema is more than the file header", "Schema Error", JOptionPane.ERROR_MESSAGE);
									}
									else{	
																		//DETERMINE THE CORRECT TYPE FOR THE SCHEMA
											correctType = new  String[typeRead.length];
																
											for(int k = 0 ; k < typeRead.length; k++ ){
												
												s = typeRead[k].trim();
												
												System.out.println("round "+k + s+ typeRead.length);
												
												//if(s.matches("[Tt]ext")||s.matches("[Ss]tring")){
												if(s.matches("[Tt]ext||[Ss]tring")){
													correctType[k] = "String";
																																
												}else if(s.matches("([Ii]nt)|([Ii]nteger)")){
													correctType[k] = "Integer";
																																			
												}else if(s.matches("([Ee]mail)")){
													correctType[k] = "Email";
													
												}
												else if(s.matches("[Bb]oolean")){
													correctType[k] = "boolean";
													
												}else if(s.matches("[Dd]ate")){
													correctType[k] = "Date";
													
												}else if(s.matches("([Dd]ouble)|([Rr]eal)|([Nn]umber)")){
													correctType[k] = "Double";
													
													}
												else if(s.matches("([Ee]mail)|(EMAIL)")){
													correctType[k] = "Email";
													
													}																	
												else{
													schemaError +=  "Unrecognise data type for field "+ k+1 + "\n";      // When data type is not among the recognise data
													System.out.println("Not match");
													}
												
											
												System.out.println("Complete round "+k + s+ typeRead.length);
												}
											}
									}
							
								else{
								JOptionPane.showMessageDialog(null, "Empty file \nPlease write proper schema", "Empty File", JOptionPane.INFORMATION_MESSAGE);
							}
													
							bufferedReader.close();
							
							} catch (FileNotFoundException e) {
							JOptionPane.showMessageDialog(null, " File not found", "NOT FOUND", JOptionPane.ERROR_MESSAGE);
						//e.printStackTrace();
						
						} catch (IOException e) {
							JOptionPane.showMessageDialog(null, e.toString(), "ERROR", JOptionPane.ERROR_MESSAGE);
							
						// TODO Auto-generated catch block
							//e.printStackTrace();
						}
				}
	
		if(schemaError.isEmpty())
			return correctType;
		else{
			textArea.setText("\n SCHEMA ERROR \n" +textArea );
			return null;
			}
		
	}
	
	public boolean  validateFieldValue( String value, String valueType  ){
		
		
				if( value.isEmpty() ){	
					return true;
				}
							
					
			   if( valueType.equalsIgnoreCase("Integer") ){	
				   						try{  Integer.parseInt(value); 
			   							return true;
			   							}
										catch( NumberFormatException e){
											return false;	
										}
			   					}
			
			   else if( valueType.equalsIgnoreCase( "Double")) {
				   						try{  Double.parseDouble(value); 
			   							return true; 
			   							}
										catch( NumberFormatException e){
											return false;
										}
			   				  }
			   
			   else if( valueType.equalsIgnoreCase( "Boolean")) {
				   						try{  Boolean.getBoolean(value); 
			   								return true;
										}

										catch( NumberFormatException e){
											return false;
										//"Invalid Integer format"
										}
			   					}
			   else if( valueType.equalsIgnoreCase( "Date"))   {	return 	parseDate(value );  }
			   
			   else if( valueType.equalsIgnoreCase( "email"))   {	return 	checkEmail(value );  }
			  
			   else return true;
											
			}
		
		
	
	
	private boolean checkEmail(String s){
		if( s.matches("(?i:[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6})")){
			return true;
		}
		
		else return false;
		
	}
	
	
	private boolean parseDate(String date ){
		
		SimpleDateFormat  dateformat = new SimpleDateFormat("dd/MM/yyyy");
		dateformat.setLenient(false);
		try{
			dateformat.parse(date);
			return true;
		}
		catch(ParseException e){
			return false;
		}
	}
	
	
	// protect the value of the field from being greater than the schema length
	private int schemaBound(int fieldCount ){
		
		if(fieldCount < schema.length ){
			return fieldCount;
		}
		else{
			return schema.length-1;
		}
	}
	
	
	private String removeClosingQuote(String v){
			if(v.isEmpty() || v == null){
				return v;
			}else{
				return v.substring(0, v.length()-1);
			}
	}
	
	
	
	/*public void highlight( String s, int pos) {
		
	//	index = editorPane.getText().indexOf(s, previousIndex);
		index = pos;
		//previousIndex = index + s.length();
		
		try {
			if(alternateColours){
				highlighter.addHighlight(index-s.length()-1, index,  highlightPainter1);
				//highlighter.addHighlight(index, index+s.length(), highlightPainter1);
				
			}
			else{
				highlighter.addHighlight(index-s.length()-1, index,  highlightPainter2);
				//highlighter.addHighlight(index, index+s.length(), highlightPainter2);
			}
			
			alternateColours = !alternateColours;
			
		} catch (BadLocationException e) {
			// TODO Auto-generated catch block
			
			JOptionPane.showMessageDialog(editorPane, "Error with the highlighter Location of \n : "+s+"\n"+ e.toString(), "Highlighter error", JOptionPane.INFORMATION_MESSAGE);
			
		}
	}


	public void removeHighlight(){ 
		highlighter.removeAllHighlights();
	}*/
		
}	
	