import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.event.UndoableEditEvent;
import javax.swing.event.UndoableEditListener;
import javax.swing.undo.CannotUndoException;
import javax.swing.undo.UndoManager;

import javax.swing.AbstractAction;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JMenu;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTabbedPane;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;

import java.awt.event.KeyEvent;
import java.awt.event.InputEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Dimension;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.HeadlessException;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JTextArea;

import javax.xml.parsers.DocumentBuilderFactory;

import org.jdom2.Element;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;


import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.SwingConstants;
import javax.swing.JScrollPane;
import java.awt.Font;
import javax.swing.JToolBar;




public class GUImain extends JFrame {

	/**
	 * Launch the application.
	 */
	final JTextArea editorPane = new JTextArea();										// main text area where the data is going to be displayed
	final JTextArea display = new JTextArea();											// for displaying errors descriptions
	JTextArea warningtxt = new JTextArea();												// for displaying some generated warning
	JTextArea suggestiontxt = new JTextArea();											// for displaying some generated suggestions
	
	FileFunctions filefunctions = new FileFunctions();									// functions class where most of the file functionalities resides
	ViewFunctions viewFunctions = new ViewFunctions();  								// functions class where most of the view functionalities resides
	
	Parser validatorObject = new Parser(editorPane);									// The main syntax parser
	parserWithCorrection correctValidation = new parserWithCorrection(editorPane);		// Parser that incorporates some corrections functionalities	
	ParserwithHighlighter validatorWithHighlight = new ParserwithHighlighter(editorPane); //Parser that incorporate highlighter
	ValuesValidation valuesValidation = new ValuesValidation(editorPane);
	
	HighlighterClass highlighterObj =  new HighlighterClass();
	
	
	UndoManager undoManager = new UndoManager(); 										// for handling undo/redo activities
	UndoControler undoControler;
	RedoControler redoControler;
	
	
	final JFileChooser fileChooserObject = new JFileChooser();      					// set the active directory to desktop
	BufferedReader bufferedReader ; 
	BufferedWriter bufferedWriter ;
	String readLine;
	String[] str;
	int result;
	Document document = new Document();
	DocumentBuilderFactory docBulFactory =  DocumentBuilderFactory.newInstance();
	
		
	//main function for the entire system
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUImain frame = new GUImain();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * 
	 * Create the frame.
	 */
	public GUImain() {
		
		setTitle("CSV Validator Application");
		setPreferredSize(new Dimension(900, 450));
		getContentPane().setPreferredSize(new Dimension(600, 600));
		getContentPane().setLayout(new GridLayout(0, 1, 0, 0));
		 
		 
		 final JPanel panel = new JPanel();
		 panel.setPreferredSize(new Dimension(700, 700));
		 panel.setBackground(new Color(255, 255, 204));
		 getContentPane().add(panel);
		 GridBagLayout gbl_panel = new GridBagLayout();
		 gbl_panel.columnWidths = new int[]{801, 146};
		 gbl_panel.rowHeights = new int[]{556, 31, 0};
		 gbl_panel.columnWeights = new double[]{3.0, 1.0};
		 gbl_panel.rowWeights = new double[]{1.0, 0.0, Double.MIN_VALUE};
		 panel.setLayout(gbl_panel);
		 editorPane.setToolTipText("");
		 editorPane.setForeground(new Color(0, 51, 0));
		   editorPane.addMouseListener(new MouseAdapter() {
		  	@Override
		  	public void mouseClicked(MouseEvent e) {
		  		if( SwingUtilities.isRightMouseButton(e) ){
		  			
		  			if(editorPane.getText().isEmpty()){
		  				popUpSimpleMenu(editorPane, e, false);
		  			}
		  			else if((editorPane.getSelectedText() == null)){
		  				popUpSimpleMenu(editorPane, e, true);
		  			}
		  			else{
			  			
			  			popUpCorrection(editorPane, e);
		  			}
		  		}	
		  	}
		  });
		  
		  editorPane.setFont(new Font("DejaVu Serif", Font.PLAIN, 18));
		  editorPane.setBackground(new Color(255, 250, 205));
		  editorPane.setAlignmentY(Component.BOTTOM_ALIGNMENT);
		  editorPane.setAlignmentX(Component.RIGHT_ALIGNMENT);
		  editorPane.setSize(new Dimension(200, 250));
		  editorPane.setMaximumSize(new Dimension(900, 250));
		//  editorPane.getDocument().addUndoableEditListener(undoManager);
		  
		  editorPane.getDocument().addUndoableEditListener( new UndoableEditListener(){
			@Override
			public void undoableEditHappened(UndoableEditEvent e) {
				// TODO Auto-generated method stub
				undoManager.addEdit(e.getEdit());
				undoControler.update();
				redoControler.update();
			}
			  
		  });
		  
		  editorPane.setHighlighter(highlighterObj.getHighlighter());
		  //
		  
		  JScrollPane jScroolBar =  new JScrollPane(editorPane);
		  TextLineNumber textLineNumber = new TextLineNumber(editorPane);					//  Line number display from Rob Camick accessed through http://tips4java.wordpress.com/2009/05/23/text-component-line-number/ ( 03/04/14 )
		  jScroolBar.setRowHeaderView(textLineNumber);
		  
		  GridBagConstraints gbc_editorPane = new GridBagConstraints();
		  gbc_editorPane.gridheight = 2;
		  gbc_editorPane.fill = GridBagConstraints.BOTH;
		  gbc_editorPane.insets = new Insets(0, 0, 0, 5);
		  gbc_editorPane.gridx = 0;
		  gbc_editorPane.gridy = 0;
		  gbc_editorPane.weightx = 4;
		  gbc_editorPane.weighty = 4;  //To set up priority in sharing spaces
		 
		  panel.add(jScroolBar, gbc_editorPane);
		  
		  JToolBar toolBar = new JToolBar();
		  jScroolBar.setColumnHeaderView(toolBar);
		  
		  JButton btnValidate = new JButton("validate");
		  btnValidate.setToolTipText("Validate the entire data");
		  btnValidate.addActionListener(new ActionListener() {
		  	public void actionPerformed(ActionEvent e) {
		  		validatorObject.validate(editorPane, display, warningtxt, suggestiontxt);
		  	}
		  });
		  toolBar.add(btnValidate);
		  
		  JButton btnHighlight = new JButton("Highlight");
		  btnHighlight.addActionListener(new ActionListener() {
		  	public void actionPerformed(ActionEvent arg0) {
		  		validatorWithHighlight.validate( display, warningtxt, suggestiontxt, highlighterObj);
		  	}
		  });
		  btnHighlight.setToolTipText("Validate the entire data with highlighting the location of detected errors");
		  toolBar.add(btnHighlight);
		  
		  JButton btnUndo = new JButton("Undo");
		  btnUndo.addActionListener(new ActionListener() {
		  	public void actionPerformed(ActionEvent e) {
		  		undoControler.undo();
		  	}
		  });
		  
		  JButton btnRemoveHighlight = new JButton("Remove Highlight");
		  btnRemoveHighlight.setToolTipText("Remove all the highlight in the data");
		  btnRemoveHighlight.addActionListener(new ActionListener() {
		  	public void actionPerformed(ActionEvent arg0) {
		  		highlighterObj.removeHighlight();		 				// call the method for removing all highlight 		
		  				  		
		  	}
		  });
		  
		  JButton btnValCorrection = new JButton("Correction");
		  btnValCorrection.setToolTipText("Validate the entire data with correcting some errors");
		  btnValCorrection.addActionListener(new ActionListener() {
		  	public void actionPerformed(ActionEvent arg0) {
		  		correctValidation.validate(editorPane, display, warningtxt, suggestiontxt);
		  	}
		  });
		  toolBar.add(btnValCorrection);
		  toolBar.add(btnRemoveHighlight);
		  toolBar.add(btnUndo);
		  
		  JButton btnRedo = new JButton("Redo");
		  btnRedo.addActionListener(new ActionListener() {
		  	public void actionPerformed(ActionEvent e) {
		  		
		  		redoControler.redo();
		  		
		  	}
		  });
		  toolBar.add(btnRedo);
		  
		  JButton btnClearView = new JButton("Tidy View");
		  btnClearView.setToolTipText("Display a tidy view  of the data");
		  btnClearView.addActionListener(new ActionListener() {
		  	public void actionPerformed(ActionEvent arg0) {
		  		viewFunctions.tidyView(editorPane);
		  	}
		  });
		  toolBar.add(btnClearView);
		  
		  JButton button = new JButton("+");
		  button.addActionListener(new ActionListener() {
		  	public void actionPerformed(ActionEvent e) {
		  		Font f = editorPane.getFont();
		  		editorPane.setFont(f.deriveFont(f.getSize() + 2f));
		  	}
		  });
		  button.setToolTipText("Zoom in");
		  toolBar.add(button);
		  
		  JButton button_1 = new JButton("-");
		  button_1.addActionListener(new ActionListener() {
		  	public void actionPerformed(ActionEvent e) {
		  		Font f = editorPane.getFont();
		  		editorPane.setFont(f.deriveFont(f.getSize() - 2f));
		  	}
		  });
		  button_1.setToolTipText("Zoom out");
		  toolBar.add(button_1);
		  
		  
		  warningtxt.setText("Warining : ");
		  warningtxt.setBackground(new Color(255, 250, 205));
		  warningtxt.setEditable(false);
		  warningtxt.setLineWrap(true);
		  warningtxt.setSize(new Dimension(10, 90));
		  warningtxt.setMaximumSize(new Dimension(10, 90));
		  JScrollPane jScroolWarning =  new JScrollPane(warningtxt);
		 
		  suggestiontxt.setText("Suggestions :");
		  suggestiontxt.setBackground(new Color(255, 250, 205));
		  suggestiontxt.setEditable(false);
		  suggestiontxt.setLineWrap(true);
		  suggestiontxt.setSize(new Dimension(10, 90));
		  suggestiontxt.setMaximumSize(new Dimension(10, 100));
		  JScrollPane jScroolSuggestion =  new JScrollPane(suggestiontxt);
		  display.setText("Errors:");
		  
		  
		  display.setEditable(false);
		  display.setBackground(new Color(255, 250, 205));
		  display.setLineWrap(true);
		  display.setSize(new Dimension(10, 90));
		  display.setMaximumSize(new Dimension(10, 100));
		  
		  JScrollPane jScroolBar1 =  new JScrollPane(display);
		  
		  JTabbedPane jtabPane = new JTabbedPane(); 
		  jtabPane.addTab("Error", jScroolBar1);
		  jtabPane.setToolTipTextAt(0, "Errors list area");
		  jtabPane.addTab("Warning", jScroolWarning);
		  jtabPane.setToolTipTextAt(1, "Warning list area");
		  jtabPane.addTab("Suggestion", jScroolSuggestion);
		  jtabPane.setToolTipTextAt(2, "Suggestions list area");
		  
		  
		  GridBagConstraints gbc_textArea = new GridBagConstraints();
		  gbc_textArea.fill = GridBagConstraints.BOTH;
		  gbc_textArea.insets = new Insets(0, 0, 5, 0);
		  gbc_textArea.gridx = 1;
		  gbc_textArea.gridy = 0;

		  panel.add(jtabPane, gbc_textArea);
		  
		  JButton btnMmm = new JButton("Clear");
		  btnMmm.addActionListener(new ActionListener() {
		  	public void actionPerformed(ActionEvent arg0) {
		  	}
		  });
		  btnMmm.addMouseListener(new MouseAdapter() {
		  	@Override
		  	public void mouseClicked(MouseEvent e) {
		  		display.setText("");
		  		warningtxt.setText("");
		  		suggestiontxt.setText("");
		  		
		  	}
		  });
		  btnMmm.setToolTipText("Clear the side bar");
		  btnMmm.setHorizontalTextPosition(SwingConstants.CENTER);
		  btnMmm.setSize(new Dimension(50, 10));
		  btnMmm.setMaximumSize(new Dimension(50, 30));
		  GridBagConstraints gbc_btnMmm = new GridBagConstraints();
		  gbc_btnMmm.fill = GridBagConstraints.BOTH;
		  gbc_btnMmm.gridx = 1;
		  gbc_btnMmm.gridy = 1;
		  panel.add(btnMmm, gbc_btnMmm);
		  
		  
		setMinimumSize(new Dimension(500, 500));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1051, 643);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setForeground(new Color(0, 0, 0));
		setJMenuBar(menuBar);
		
		JMenu mnFile = new JMenu("File");
		mnFile.setIcon(new ImageIcon(GUImain.class.getResource("/com/sun/java/swing/plaf/windows/icons/File.gif")));
		menuBar.add(mnFile);
		
		JMenuItem mntmOpen = new JMenuItem("Open");
		mntmOpen.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent arg0) {
				 filefunctions.openFile(editorPane);
			}

		});
		mntmOpen.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		
		mntmOpen.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.CTRL_MASK));
		mntmOpen.setIcon(new ImageIcon(GUImain.class.getResource("/com/sun/java/swing/plaf/windows/icons/TreeOpen.gif")));
		mnFile.add(mntmOpen);
		
		JMenuItem mntmSave = new JMenuItem("Save");
		mntmSave.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_MASK));
		mntmSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				filefunctions.save(panel, editorPane);
			}
		});
		
		JMenuItem mntmAddFile = new JMenuItem("Add file");
		mntmAddFile.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.SHIFT_MASK));
		mntmAddFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				filefunctions.addFile(editorPane);
			}
		});
		mnFile.add(mntmAddFile);
		mnFile.add(mntmSave);
		
		JMenu mnExport = new JMenu("Export");
		mnFile.add(mnExport);
		
		JMenuItem mntmAsPdf = new JMenuItem("as PDF");
		mntmAsPdf.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                      filefunctions.exportPDF(editorPane);
			}
		});
		mnExport.add(mntmAsPdf);
		
		JMenuItem mntmAsXml = new JMenuItem("as XML");
		mntmAsXml.addActionListener(new ActionListener() {
			@SuppressWarnings("null")
			public void actionPerformed(ActionEvent arg0) {
				filefunctions.exportXML(editorPane, display);
			}
		});
		mnExport.add(mntmAsXml);
		
		JMenuItem mntmAsCsv = new JMenuItem("as CSV");
		mnExport.add(mntmAsCsv);
		
		JMenuItem mntmAsDocx = new JMenuItem("as docx");
		mnExport.add(mntmAsDocx);
		
		JMenuItem mntmAsOdf = new JMenuItem("as ODF");
		mnExport.add(mntmAsOdf);
		
		JMenuItem mntmExit = new JMenuItem("Exit");
		mntmExit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F4, InputEvent.ALT_MASK));
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(1);
			}
		});
		mnFile.add(mntmExit);
		
		JMenu mnValidation = new JMenu("  Validation");
		mnValidation.setIcon(new ImageIcon(GUImain.class.getResource("/javax/swing/plaf/metal/icons/ocean/expanded.gif")));
		menuBar.add(mnValidation);
		
		MnuItemValidation = new JMenuItem("Validate");
		MnuItemValidation.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_B, InputEvent.CTRL_MASK));
		MnuItemValidation.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) throws HeadlessException {
				validatorObject.validate( editorPane, display, warningtxt, suggestiontxt);
		}
		});
		mnValidation.add(MnuItemValidation);
		
		JMenuItem MnItemHighlight = new JMenuItem("Validation with Highlight");
		MnItemHighlight.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_H, InputEvent.CTRL_MASK));
		MnItemHighlight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				validatorWithHighlight.validate( display, warningtxt, suggestiontxt, highlighterObj);
			}
		});

		mnValidation.add(MnItemHighlight);
		
		JMenuItem mntmContentValidation = new JMenuItem("Content Validation");
		mntmContentValidation.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_D, InputEvent.CTRL_MASK));
		mntmContentValidation.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				valuesValidation.validate(display, warningtxt, suggestiontxt, highlighterObj);
				//advancedValidation();
			}
		});
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Validation with Correction");
		mntmNewMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_K, InputEvent.CTRL_MASK));
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				correctValidation.validate(editorPane, display, warningtxt, suggestiontxt);
			}
		});
		mnValidation.add(mntmNewMenuItem);
		
		mnValidation.add(mntmContentValidation);
		
		JMenu mnTool = new JMenu("Tool");
		mnTool.setIcon(new ImageIcon(GUImain.class.getResource("/javax/swing/plaf/metal/icons/ocean/computer.gif")));
		
		undoControler = new UndoControler();
		redoControler = new RedoControler();
		
		JMenuItem menuItem = mnTool.add(undoControler);
		menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z, InputEvent.CTRL_MASK));
		JMenuItem menuItem_1 = mnTool.add(redoControler);
		menuItem_1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Y, InputEvent.CTRL_MASK));
		
		menuBar.add(mnTool);
		
		JMenuItem mntmRemoveHighlight = new JMenuItem("Remove Highlight");
		mntmRemoveHighlight.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_H, InputEvent.SHIFT_MASK));
		mntmRemoveHighlight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				highlighterObj.removeHighlight();		  		
				//valuesValidation.removeHighlight();
				//validatorWithHighlight.removeHighlight();
			}
		});
		mnTool.add(mntmRemoveHighlight);
		
		JMenuItem mntmFindAndReplace = new JMenuItem("Find and Replace");
		mntmFindAndReplace.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_MASK));
		mntmFindAndReplace.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				FindReplace fr = new  FindReplace(editorPane);
				fr.setVisible(true);
			}
		});
		mnTool.add(mntmFindAndReplace);
		
		JMenu mnView = new JMenu("  View    ");
		mnView.setIcon(new ImageIcon(GUImain.class.getResource("/com/sun/java/swing/plaf/windows/icons/DetailsView.gif")));
		menuBar.add(mnView);
		
		JMenuItem mnItemClearView = new JMenuItem("Tidy View");
		mnItemClearView.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_T, InputEvent.CTRL_MASK));
		mnItemClearView.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				viewFunctions.tidyView(editorPane);		
			}
		});
		
		JMenuItem mntmCommaView = new JMenuItem("Comma view");
		mntmCommaView.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, InputEvent.SHIFT_MASK));
		mntmCommaView.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				viewFunctions.commaView(editorPane);
				
			}
		});
		mnView.add(mntmCommaView);
		mnItemClearView.setToolTipText("Dispaly a tidy view of the data, like Tab Separated format");
		mnItemClearView.setActionCommand("tabView");
		mnView.add(mnItemClearView);
		
		JMenu mnItemHelp = new JMenu("Help");
		mnItemHelp.setIconTextGap(2);
		menuBar.add(mnItemHelp);
		
		JMenuItem mnItemGuide = new JMenuItem("Guide");
		mnItemGuide.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String guide = "", line;
				JTextArea guideArea = new JTextArea();
				//guideArea.setFont(new Font("DejaVu Serif", Font.PLAIN, 14));
				
				try{
					InputStreamReader in = new InputStreamReader(this.getClass().getResourceAsStream("help"));
					
					BufferedReader r = new BufferedReader(in);
					while((line = r.readLine()) != null){
						guideArea.append(line +"\n");
					}
					
					r.close();
				}catch(IOException e){
					JOptionPane.showMessageDialog(editorPane, "Error reading the help file", "ERROR", JOptionPane.ERROR_MESSAGE);
				}
				catch (Exception e) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Encouter error with the help file\n"+e.toString(), "Error",   JOptionPane.ERROR_MESSAGE);
				e.printStackTrace();
				}
				
				guideArea.setLineWrap(true);
				guideArea.setEditable(false);
				JScrollPane sp = new JScrollPane(guideArea);
				sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
				sp.setPreferredSize(new Dimension(500, 500));
				JOptionPane optionPane = new JOptionPane(sp); 
				JDialog dialog = optionPane.createDialog("Guide");  
			    dialog.setModal(true);  
			    dialog.setVisible(true);  
				
			}
		});
		mnItemGuide.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0));
		mnItemGuide.setIcon(new ImageIcon(GUImain.class.getResource("/com/sun/java/swing/plaf/windows/icons/File.gif")));
		mnItemHelp.add(mnItemGuide);
		
		JMenuItem mnItemAbout = new JMenuItem("About");
		mnItemAbout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
								
				String about = "This application has been designed for validating CSV file \n\t By A.H.Abba\n\t Email: ahagmj@gmail.com";

				JTextArea aboutArea = new JTextArea();
				aboutArea.setText(about);
				aboutArea.setEditable(false);
				JOptionPane optionPane = new JOptionPane(aboutArea); 
				JDialog dialog = optionPane.createDialog("About");  
			    dialog.setVisible(true);  
				
			}
		});
		mnItemAbout.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F2, 0));
		mnItemAbout.setIcon(new ImageIcon(GUImain.class.getResource("/com/sun/java/swing/plaf/windows/icons/HomeFolder.gif")));
		mnItemHelp.add(mnItemAbout);
			
	}   
	
	
	
	ActionListener actionListener = new ActionListener(){
		public void actionPerformed(ActionEvent arg0){
			editorPane.replaceSelection(arg0.getActionCommand());
		}
	};
	private JMenuItem MnuItemValidation;
	

	public void popUpCorrection(final JTextArea jtextArea, MouseEvent e){
		
		JPopupMenu jpopUpCorrection = new JPopupMenu( "Correction popUp");
			
		if(!(jtextArea.getText().isEmpty())){
			String[] sug = generateSuggestion( jtextArea.getSelectedText() );
			int l  = sug.length;
			
			JMenuItem[] mn = new JMenuItem[l];
			
				for(int a = 0; a < sug.length; a++){
					mn[a] = new JMenuItem(sug[a]);
					mn[a].addActionListener(actionListener);
					jpopUpCorrection.add(mn[a]);
				}
		}
		
		
		jpopUpCorrection.setBackground(Color.green);
		
		jtextArea.add(jpopUpCorrection);
		
		jpopUpCorrection.show(jtextArea, e.getX(), e.getY() );
		
			
	}
	
	
	public String[] generateSuggestion( String s){
		
		
		ArrayList<String> suggestion = new ArrayList<String>();
		
		Matcher matcher;
		
		
		//Remove all non escape quote
		if(s.matches(".*\"{1}.*" )){
			matcher = Pattern.compile("[^\",\n]\"[^\",\n]").matcher(s);
			if(matcher.find()){
				suggestion.add(s.replaceAll(matcher.group(), matcher.group().replace("\"", "")));
			}
		}

		
		//Escape all non escape quote
		if(s.matches(".*[^\"]\"[^\"].*" )){
			matcher = Pattern.compile("[^\",\n]\"[^\",\n]").matcher(s);
			if(matcher.find()){
				suggestion.add(s.replaceAll(matcher.group(), matcher.group().replace("\"", "\"\"")));
			}
		}
			
			
		//Convert triple quote to double quote
		if(s.matches(".*[^\"](\"){3}[^\"].*" )){
			suggestion.add(s.replaceAll("(\"){3}", "\"\"")); 
		}
		
		//Convert triple quote to quadrant quote
		if(s.matches(".*[^\"](\"){3}[^\"].*" )){
			suggestion.add(s.replaceAll("(\"){3}", "\"\"\"\"")); 
		
				}
		
		
		//Convert double consecutive comma to single
		if(s.matches(".*,,.*")){
			suggestion.add( s.replaceFirst(",,", ","));	
			}
		
		
		//convert all consecutive single quote to double quote
		if(s.matches(".*''.*")){
			suggestion.add( s.replaceAll("''", "\""));	
			}
		
		// Enclose escaped quote inside quotation
		if(s.matches(".*[^\"](\"\")[^\"].*")){
			//suggestion.add(s.replaceAll("(\"){3}", "\"\""));
			matcher = Pattern.compile("[^,]*[^\",](\"\")[^\",][^,]*").matcher(s);       // error no match found
			
			if(matcher.find()){
				suggestion.add(s.replace(matcher.group(), "\""+matcher.group()+ "\""));			
				}
			}
		
		
		// Close opened quote
		if(s.matches(".*,\".*[^\"](\"\")[^\"].*")){
					//suggestion.add(s.replaceAll("(\"){3}", "\"\""));
			matcher = Pattern.compile(",\"[^,]*[^\",](\"\")[^\",][^,]*").matcher(s);       // error no match found
				if(matcher.find()){
				suggestion.add(s.replace(matcher.group(), matcher.group()+ "\""));			
				
				}
				}
			
		// Insert opening quotation
		if(s.matches(".*[^\"](\"\")[^\"].*\",.*")){
			//suggestion.add(s.replaceAll("(\"){3}", "\"\""));
			matcher = Pattern.compile("[^,]*[^\",](\"\")[^\",][^,]*\",").matcher(s);       // error no match found
			if(matcher.find()){
				suggestion.add(s.replace(matcher.group(), "\""+matcher.group() ));			
			}
			}
		
		//Remove spaces between two quotation
			if(s.matches(".*(\" \").*")){
				suggestion.add(s.replaceAll("\" \"", "\"\""));
			}
				
		
		// Enclose line break inside quotation
		if(s.matches(".*,[^\"]*\n[^\"]*,.*")){
			//suggestion.add(s.replaceAll("(\"){3}", "\"\""));
			matcher = Pattern.compile("[^\",]*\n[^\",]*").matcher(s);       // error no match found
				if(matcher.find()){
					suggestion.add(s.replace(matcher.group(), "\""+matcher.group()+ "\""));			
				}
			}
		
		
		
			suggestion.add( s.replace("\"", ""));				// remove all the quote
	
			suggestion.add( s + '\"');							// Insert quote at the ending
			suggestion.add('\"'+s);								// insert quote at the beginning
			suggestion.add( s.replaceFirst(",", "\","));		// Insert quote before the first comma
			suggestion.add( s.replaceFirst("\"", ""));			// Remove the first quote
			suggestion.add( s.replaceFirst("\"", "\"\""));		// Escape the first quote
				
	//	}
		//String[] genSuggestion = { "suggestion number one ", "suggestion number two ", "suggestion number three ", s};
		
		//genSuggestion[0] = s;
		
		return  suggestion.toArray(new String[suggestion.size()]);
		
	}
	
	
	
public void popUpSimpleMenu(final JTextArea jtextArea, MouseEvent e, Boolean b){
		
		JPopupMenu jpopUpsimple = new JPopupMenu( "Correction popUp");
	
		JMenuItem mn1 = new JMenuItem("Open File");
		JMenuItem mn2 = new JMenuItem("Add File");
		JMenuItem mn3 = new JMenuItem("exit");
		JMenuItem mn4 = new JMenuItem("Validate");
		JMenuItem mn5 = new JMenuItem("Correction");
		JMenuItem mn6 = new JMenuItem("Content Validation");
		
		mn4.setEnabled(false);
		mn5.setEnabled(false);
		mn6.setEnabled(false);
				
		jpopUpsimple.add(mn1);
		jpopUpsimple.add(mn2);
		jpopUpsimple.add(mn3);
		jpopUpsimple.add(mn4);
		jpopUpsimple.add(mn5);
		jpopUpsimple.add(mn6);
		
		
		mn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0){
				filefunctions.openFile(jtextArea);
			}
		});
		
		mn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0){
				filefunctions.addFile(jtextArea);
			}
		});
		
		mn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0){
				System.exit(1);
			}
		});
		
		mn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0){
				validatorObject.validate(editorPane, display, warningtxt, suggestiontxt);
			}
		});
		
		mn5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0){
				//advancedValidation();
				correctValidation.validate(editorPane, display, warningtxt, suggestiontxt);
				
			}
		});
		
		
		mn6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0){
				//advancedValidation();
				valuesValidation.validate(display, warningtxt, suggestiontxt, highlighterObj);
				
			}
		});
		
		
		
		if(b){
			mn4.setEnabled(true);
			mn5.setEnabled(true);
			mn6.setEnabled(true);
		}
		
		jpopUpsimple.setBackground(Color.green);
		jtextArea.add(jpopUpsimple);
		jpopUpsimple.show(jtextArea, e.getX(), e.getY() );
			
	}

/*	public void advancedValidation() {
	
		String error = "";
		int recordline = 0, position = 0; 
		AdvancedValidator advVal =  new AdvancedValidator();	
		
		if(validatorObject.validate(editorPane, display, warningtxt, suggestiontxt)){
			
			String[] validSchema = advVal.validateSchema(display);
	        String[] arrangeRecord = advVal.arrangeRecord(editorPane);
	        
	        for(int a = 1; a < arrangeRecord.length; a++){
	        	
	        	 String[] values = advVal.arrangeValues(arrangeRecord[a]);
	        	 
	        	 // To ensure the robustness of the application
	        	 if(values.length == validSchema.length){
	        		 for(int b = 0 ; b < values.length; b++){
	        			 
	        			 if( ! advVal.validateFieldValue(values[b], validSchema[b])){
	        				 	 error += "\nIn record "+a+" that span line "+ validatorObject.mapRecordtoLine.get(a)+ " field "+(b+1) + " has invalid data";
	        				 	 
	        				 	 // using a value to hold the the ending of each record
	        				 	//validatorWithHighlight.highlight(values[b], recordline+position);
	        				 	highlighterObj.highlight(values[b], recordline+position);	  		
	        				 	 
	        			 	}
	        		 	}
	        	 	}
	        	 else{
	        		 
	        		 error += "\n Record "+a+" is incomplete";
	        		 
	        		 System.out.println( "record "+a+" is not the same with the schema length " );
	        		 System.out.println(  "schema length : "+ validSchema.length  + "while record legth is :"+values.length);
	        	 }
	        	
	        }
			            
	        display.setText(" DATA TYPE validation errors"+ error);
		}
}*/

///////////////////////////UNDO CODE BEGIN


private class UndoControler extends AbstractAction{

	UndoControler(){
		super("Undo");
		setEnabled(false);
		}
		
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
		undo();
		
	}

	private void undo() {
		try{
			undoManager.undo();
		}
		catch(CannotUndoException e){
			JOptionPane.showMessageDialog(editorPane, "Can not undo the action", "Cannot Undo", JOptionPane.INFORMATION_MESSAGE);		
		}
		redoControler.update();
		update();
	}
	
	public void update(){
		if(undoManager.canUndo()){
			setEnabled(true);
		}
		else{
			setEnabled(false);
		}
		
	}
	
}


private class RedoControler extends AbstractAction{
	
	RedoControler(){
		super("Redo");
		setEnabled(false);
		}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
		redo();
		
	}

	private void redo() {
		try{
			undoManager.redo();
		}
		catch(CannotUndoException e){
			JOptionPane.showMessageDialog(editorPane, "Can not redo the action", "Cannot Rddo", JOptionPane.INFORMATION_MESSAGE);		
		}
		undoControler.update();
		update();
	}
	
	public void update(){
		if(undoManager.canRedo()){
			setEnabled(true);
		}
		else{
			setEnabled(false);
		}
	}
}

	 

}   //  W1frame Class end
