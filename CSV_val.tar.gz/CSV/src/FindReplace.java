import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class FindReplace extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField findtxt;
	private JTextField Replacetxt;
	final Highlighter highlighter;
	final Highlighter.HighlightPainter highlightPainter;

	

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		try {
			FindReplace dialog = new FindReplace(new JTextArea());
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
*/
	/**
	 * Create the dialog.
	 */
	public FindReplace( final JTextArea jtextarea ) {
		setResizable(false);
		setTitle("Find and Replace dialog");
		setBounds(500, 400, 500, 130);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		
		 highlighter = new  DefaultHighlighter();
		 highlightPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.GREEN);
		
		
		{
			findtxt = new JTextField();
			contentPanel.add(findtxt);
			findtxt.setColumns(22);
		}
		{
			JButton btnNewButton = new JButton("   Find   ");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					find( jtextarea, findtxt.getText() );
					
				}
			});
			contentPanel.add(btnNewButton);
		}
		{
			JButton btnNewButton_1 = new JButton("   Find  All  ");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					findAll( jtextarea, findtxt.getText() );
				}
			});
			contentPanel.add(btnNewButton_1);
		}
		{
			Replacetxt = new JTextField();
			contentPanel.add(Replacetxt);
			Replacetxt.setColumns(22);
		}
		{
			JButton replacebtn = new JButton("Replace");
			replacebtn.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					replace( jtextarea, findtxt.getText(), Replacetxt.getText() );					
					
				}
			});
			contentPanel.add(replacebtn);
		}
		{
			JButton btnReplaceAll = new JButton("Replace all");
			btnReplaceAll.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					replaceAll( jtextarea, findtxt.getText(), Replacetxt.getText() );	
				}
			});
			contentPanel.add(btnReplaceAll);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				/*JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);*/
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						highlighter.removeAllHighlights();
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
	


private void find( JTextArea jtextarea, String str){
	int i = jtextarea.getText().toLowerCase().indexOf(str.toLowerCase());
	jtextarea.setHighlighter(highlighter);
	
	try {
		highlighter.addHighlight(i, i+str.length(), highlightPainter);
	} catch (BadLocationException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

private void findAll( JTextArea jtextarea, String str){
	int i = 0;
	jtextarea.setHighlighter(highlighter);
	
	try {
		
		while( (i = jtextarea.getText().toLowerCase().indexOf(str.toLowerCase(), i)) > 0){
			highlighter.addHighlight(i, i+str.length(), highlightPainter);
			i = i + str.length();
		}
		
	} catch (BadLocationException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
private void replace( JTextArea jtextarea, String replaced, String replacement){
	int i = jtextarea.getText().toLowerCase().indexOf(replaced.toLowerCase());
	if( i > 0 ) {
		jtextarea.replaceRange(replacement, i, i + replaced.length());
	}
	
	//jtextarea.setText(jtextarea.getText().replaceFirst(replaced, replacement));
}

private void replaceAll( JTextArea jtextarea, String replaced, String replacement){
	int i = 0;

		while( (i = jtextarea.getText().toLowerCase().indexOf(replaced.toLowerCase(), i)) > 0){
			jtextarea.replaceRange(replacement, i, i+ replaced.length());
			i = i + replaced.length();
		}
		
	}
	
	
}
