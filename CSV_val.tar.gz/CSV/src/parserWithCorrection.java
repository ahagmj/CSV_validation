import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;


public class parserWithCorrection {
	
	int headerLength, recordCounter;
	JTextArea editorPane, display;
	public HashMap<Integer, String> mapRecordtoLine;
	ArrayList<String> arrangeRecord = new  ArrayList<String>();
	String  errors = "", newText = "";
	
	
	//String  errortxt, warningtxt, suggestiontxt;
	
	
	parserWithCorrection( JTextArea textArea  ){
		editorPane = textArea;
	}
	
	
	//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<Functions implementation,
	int headerSize(){
		 
		int header = 0;
		
		if(  ( JOptionPane.showConfirmDialog(null, "Is the first line header ?", "Verify Header", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE)== 0 )) 
		 {
			header =  editorPane.getText().split("\n")[0].split(",").length;
			
			recordCounter = 0;    								 // Data start form second line
			System.out.print(" Headersize : "+header);
		 }
		else{
			 
			String noOfFields = JOptionPane.showInputDialog(editorPane, "Please how many fields are in the data ?", "Number of fields", JOptionPane.QUESTION_MESSAGE);
			
			try{ header = Integer.parseInt(noOfFields); }				
			catch(NumberFormatException ex){
				
				//  To catch empty and null
				JOptionPane.showMessageDialog(editorPane, "Unrecognised input", "INPUT ERROR", JOptionPane.ERROR_MESSAGE);
				return -1;
							
				}
			recordCounter = 1;    								 // Data start from first line
		 } 
		return header;
	}
	
	public boolean validate(JTextArea editorPane,JTextArea display, JTextArea warningtxt, JTextArea suggestiontxt){
				
		if(editorPane.getText().isEmpty()){
			JOptionPane.showMessageDialog(editorPane, "The text editor has nothing to validate.", "Caution", JOptionPane.INFORMATION_MESSAGE);
			return false;
		}
		
			// Not empty
		else{
			headerLength = headerSize();
			if(headerLength < 0){
				JOptionPane.showMessageDialog(editorPane, " Negative is an inavalid header length.\nThe process has been terminated", "INVALID HEADER LENGHT", JOptionPane.ERROR_MESSAGE);
				return false;
			}
			mapRecordtoLine =  new  HashMap<Integer, String>();
			mapRecordtoLine.put(1, 1+" to "+1);										//Initialise for the first record to take care of null for firstline error
			
			parse( editorPane.getText() );
			display.setText( ">>>Errors :\n" + errors);
			editorPane.setText(newText);
			newText = "";
			
		}
		
		if(errors.isEmpty()){
			return true; }
		else{
			return false;		}
	}


	String parse( String text ){
	
		String record = "", value = "", errorText = "", enclosedValue;
		char quote = '\"', delimiter  = ',', endLine = '\n', space = ' ';
		
		boolean pre_escape = false, openQuote = false, begin_field = true, enclose = false;
		
		int errorCounter = 0,  recBegin = 1, currentLine = 1, openQuotePosition = 0;
		
		ArrayList<String> values = new  ArrayList<String>();
		arrangeRecord.clear();
		
		
		
		for( char c : text.toCharArray() ){
		
			
			
			if( c == delimiter ){
				if( !openQuote && !begin_field && !pre_escape ){
					begin_field = true;
					
					if(enclose){
					
						enclose = false;
						enclosedValue = "\""+ value + "\"";
						values.add(enclosedValue);
												
						record = record.replace(value, enclosedValue);
						
						System.out.println("value : "+ value+ "enclose value : "+ enclosedValue );
						//JOptionPane.showMessageDialog(editorPane, "value : "+ value+ "\nenclose value : "+ enclosedValue+ "\nRecord: "+record , "  Display ", JOptionPane.ERROR_MESSAGE);
						
					}else{
						values.add(value);					//Add the last value since it will not have end delimiter
					}
					
					//values.add(value);
					value = "";
				}
				else if( !openQuote && begin_field && !pre_escape ){
					if(enclose){
						enclose = false;
						enclosedValue = "\""+ value + "\"";
						values.add(enclosedValue);
						record = record.replace(value, enclosedValue);
					}else{
						values.add(value);					//Add the last value since it will not have end delimiter
					}
					
					//values.add(value);
					value = "";
					
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					openQuote = false;
					begin_field = true;
					pre_escape = false;
										
					
					if(enclose){
						enclose = false;
						enclosedValue = "\""+ value + "1\"";
						values.add(enclosedValue);
						record = record.replace(value, enclosedValue);
					}else{
						values.add(value);					//Add the last value since it will not have end delimiter
					}
					
					//values.add(value);
					
					
					value = "";
										
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
					
				}
			}
			else if( c ==  endLine){
				if( !openQuote && !begin_field && !pre_escape ){
					begin_field = true;
					
					if(enclose){
						enclose = false;
						enclosedValue = "\""+ value + "\"";
						values.add(enclosedValue);
						record = record.replace(value, enclosedValue);
					}else{
						values.add(value);					//Add the last value since it will not have end delimiter
					}
					
					
					//values.add(value);					//Add the last value since it will not have end delimiter
					
					arrangeRecord.add(record);				//Add a record
					mapRecordtoLine.put(recordCounter, (recBegin)+" to "+(currentLine));
					recordCounter++;
					
								
					if(values.size() < headerLength ){
						errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has less than the required data"; 					
					}
					else if(values.size() > headerLength ){
						errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has more than the expected data"; 					
					}
					
					value = "";
					record = "";
					recBegin = currentLine + 1;
					values.clear();
		
				}
				else if( !openQuote && begin_field && !pre_escape ){
					
					if(enclose){
						enclose = false;
						enclosedValue = "\""+ value + "\"";
						values.add(enclosedValue);
						record = record.replace(value, enclosedValue);
					}else{
						values.add(value);					//Add the last value since it will not have end delimiter
					}
					
					
					arrangeRecord.add(record);				//Add a record
					mapRecordtoLine.put(recordCounter, (recBegin)+" to "+(currentLine));
					recordCounter++;
					
								
					if(values.size() < headerLength ){
						errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has less than the required data"; 					
					}
					else if(values.size() > headerLength ){
						errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has more than the expected data"; 					
					}
					
					value = "";
					record = "";
					recBegin = currentLine + 1;
					values.clear();
					
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					openQuote = false;
					begin_field = true;
					pre_escape = false;
					
					
					if(enclose){
						enclose = false;
						enclosedValue = "\""+ value + "\"";
						values.add(enclosedValue);
						record = record.replaceAll(value, enclosedValue);
					}else{
						values.add(value);					//Add the last value since it will not have end delimiter
					}
					
					arrangeRecord.add(record);				//Add a record
					mapRecordtoLine.put(recordCounter, (recBegin)+" to "+(currentLine));
					recordCounter++;
								
					if(values.size() < headerLength ){
						errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has less than the required data"; 					
					}
					else if(values.size() > headerLength ){
						errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has more than the expected data"; 					
					}
					
					value = "";
					record = "";
					recBegin = currentLine + 1;
					values.clear();
					
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
				}
				
				currentLine++;
				
			}
			else if( c ==  space ){
				value += c;
				if( !openQuote && !begin_field && !pre_escape ){
					
				}
				else if( !openQuote && begin_field && !pre_escape ){
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					pre_escape = false;
					errorText +=  "\n\n"+ ++errorCounter +": UNESCAPE QUOTE:   at line " +(currentLine)+". CORRECTED it has been escaped";
					record += "\"";
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
				}
			}
			else if( c == quote ){
				value += c;
				
				if( !openQuote && !begin_field && !pre_escape ){
					
					errorText +=  "\n\n"+ ++errorCounter +": UNENCLOSED QUOTE: at line " +(currentLine)+". CORRECTED it has been enclosed";
					enclose = true;
					
				}
				else if( !openQuote && begin_field && !pre_escape ){
					
					openQuote = true;
					openQuotePosition =  currentLine;
					
					begin_field = false;
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					pre_escape = true; 
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					pre_escape = false;
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
				}
			}
			else{
				value += c;
				if( !openQuote && !begin_field && !pre_escape ){
					
				}
				else if( !openQuote && begin_field && !pre_escape ){
					
					begin_field = false; 
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					pre_escape = false;
					record += "\"";
					
					errorText +=  "\n\n"+ ++errorCounter +": UNESCAPE QUOTE:   at line " +(currentLine)+ ". CORRECTED, it has been escaped";
					
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
				}
			}
			
			
			record += c;
			
			
		}
		
		
		
		
		// Add the last record since it may not have endline character
		
		if(enclose){
			enclose = false;
			enclosedValue = "\""+ value + "\"";
			values.add(enclosedValue);
			record = record.replace(value, enclosedValue);
		}else{
			values.add(value);					//Add the last value since it will not have end delimiter
		}
												
		arrangeRecord.add(record);
		mapRecordtoLine.put(recordCounter, (recBegin)+" to "+(currentLine));
	
		
		if(values.size() < headerLength ){
			errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has less than the required data"; 					
		}
		else if(values.size() > headerLength ){
			errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has more than the expected data"; 					
		}
		
		if(openQuote){
			errorText +=  "\n\n"+ ++errorCounter +": UNCLOSE OPEN QUOTE :  at line " +(openQuotePosition);
		}
		
		newText = "";
		for(String r : arrangeRecord){
				newText += r; 
		}
		

		
	// Completed, assign the errors for display and return the records.	
		
		errors = errorText;
		return	 newText;
    }
	
	
	
	
}	
	