import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import org.jdom2.Element;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;


public class FileFunctions {
	
	final JFileChooser fileChooserObject = new JFileChooser();
	int result;
	String readLine;
	Document document = new Document();
	BufferedReader bufferedReader ; 
	BufferedWriter bufferedWriter ;
	
			public void exportPDF( final JTextArea editorPane ) {
				result = fileChooserObject.showSaveDialog(editorPane);
				
				    if(result == JFileChooser.APPROVE_OPTION){
					File file = fileChooserObject.getSelectedFile();
					file.renameTo(new File(file.getAbsolutePath()+".pdf")); 
					try {
						PdfWriter.getInstance(document, new FileOutputStream(file) );
						document.open();
						document.newPage();
						document.add(new Paragraph(editorPane.getText()));
						document.close();
							
					} catch (DocumentException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					}
			}
	
	
	
			public void exportXML(final JTextArea editorPane, final JTextArea errorDisplay) {
		
			
			String text=editorPane.getText(), valueItem = "";
			//char delimeter = ',', nextline = '\n', quote = '\"';
			boolean openQ = false, escape = false, detectHeader = false;
			String fields[];
			Element element = new Element("element");
			int headerLength, recordCounter = 0;
			JTextArea  display;
			HashMap<Integer, String> mapRecordtoLine =  new  HashMap<Integer, String>();
			ArrayList<String> arrangeRecord = new  ArrayList<String>();
			String  errorText = "";//, errors = "";
			 
			
			try {											//    NEED TO BE FIXED  ??????????????????
									
				result = fileChooserObject.showSaveDialog(null);
				
			    if(result == JFileChooser.APPROVE_OPTION){
					File file = fileChooserObject.getSelectedFile();
					file.renameTo(new File(file.getAbsolutePath()+".xml"));
					
					
					org.jdom2.Document docj = new org.jdom2.Document();
					Element table = new Element("Table");
					docj.setRootElement(table);
					
					
		// CONSTRUCT THE STRUCTURE OF THE XML
					
					if(  ( JOptionPane.showConfirmDialog(null, "Is the first line header ?", "Verify Header", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE)== 0 )) 
					 {
						
						//headerSize =  editorPane.getText().split("\n")[0].split(",").length;
						fields =   editorPane.getText().split("\n")[0].split(",");                                  //allRecords[0].split(",");    // Read the header
						headerLength =  fields.length;
						detectHeader = true;
						recordCounter = 0;
					 }
					else{
						
						int header ;
						recordCounter = 0;
						String noOfFields = JOptionPane.showInputDialog(editorPane, "Please how many fields are in the data ?", "Number of fields", JOptionPane.QUESTION_MESSAGE);
						
						// TO DO HERE; Detect empty   
						// Detect cancel   
						
						System.out.print(" no of fields is :"+ noOfFields);
										
						try{ headerLength = Integer.parseInt(noOfFields);
						
						if(headerLength < 0){
							JOptionPane.showMessageDialog(editorPane, "Negative is an inavalid header length.\nThe process has been terminated", "INVALID HEADER LENGHT", JOptionPane.ERROR_MESSAGE);
							return;
							
						}
						
							fields = new String[headerLength];
							
							for(int i = 1; i<= headerLength; i++){
								fields[i-1] = "value"+i;
							}
							
						}				
						catch(NumberFormatException ex){
							
							//  To catch empty and null
							JOptionPane.showMessageDialog(editorPane, "Unrecognised input", "INPUT ERROR", JOptionPane.ERROR_MESSAGE);
							return;
										
							}
						
					 } 

					
					//   GENERATE XML
					
					String record = "", value = "";
					char quote = '\"', delimiter  = ',', endLine = '\n', space = ' ';
					
					boolean pre_escape = false, openQuote = false, begin_field = true;
					
					int errorCounter = 0,  recBegin = 1, currentLine = 1, openQuotePosition = 0, fieldCounter = 0;;
					
					ArrayList<String> values = new  ArrayList<String>();
					
					
					for( char c : text.toCharArray() ){
					
						record += c;
						
						if( c == delimiter ){
							if( !openQuote && !begin_field && !pre_escape ){
								begin_field = true;
								
								element.addContent(new Element( fields[fieldCounter] ).setText(value ));
								
								if(fieldCounter < (fields.length - 1) ){
								fieldCounter++;	}
								else{
									System.out.print("fieldCounter = " +fieldCounter + " fieldCounter exceed number of fields");
								}
								
								values.add(value);
								value = "";
							}
							else if( !openQuote && begin_field && !pre_escape ){
								
								element.addContent(new Element( fields[fieldCounter] ).setText(value ));
							
								if(fieldCounter < (fields.length - 1) ){
								fieldCounter++;	}
								else{
									System.out.print("fieldCounter = " +fieldCounter + " fieldCounter exceed number of fields");
								}
								
								values.add(value);
								value = "";
								
								
							}
							else if( openQuote && !begin_field && !pre_escape ){
								value += c;
							}
							else if( openQuote && !begin_field && pre_escape ){
								openQuote = false;
								begin_field = true;
								pre_escape = false;
								
								element.addContent(new Element( fields[fieldCounter] ).setText(value ));
								
								if(fieldCounter < (fields.length - 1) ){
								fieldCounter++;	}
								else{
									System.out.print("fieldCounter = " +fieldCounter + " fieldCounter exceed number of fields");
								}
								
								values.add(value);
								value = "";
													
							}
							else{
								// Unreachable stage
								JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
								
							}
						}
						else if( c ==  endLine){
							if( !openQuote && !begin_field && !pre_escape ){
								begin_field = true;
								
								values.add(value);					//Add the last value since it will not have end delimiter
								
								arrangeRecord.add(record);				//Add a record
								mapRecordtoLine.put(recordCounter, (recBegin)+" to "+(currentLine));
								recordCounter++;
								
								if( !detectHeader ){
									
									element.addContent(new Element( fields[fieldCounter] ).setText(value ));
									docj.getRootElement().addContent(element);
									}else{
										detectHeader = false;
									}
									
									element = new Element("element");
									fieldCounter = 0;
								
											
								if(values.size() < headerLength ){
									errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has less than the required data"; 					
								}
								else if(values.size() > headerLength ){
									errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has more than the expected data"; 					
								}
								
								value = "";
								record = "";
								recBegin = currentLine + 1;
								values.clear();
					
							}
							else if( !openQuote && begin_field && !pre_escape ){
								
								values.add(value);					//Add the last value since it will not have end delimiter
								
								arrangeRecord.add(record);				//Add a record
								mapRecordtoLine.put(recordCounter, (recBegin)+" to "+(currentLine));
								recordCounter++;
								
								if( !detectHeader ){
									
									element.addContent(new Element( fields[fieldCounter] ).setText(value ));
									docj.getRootElement().addContent(element);
									}else{
										detectHeader = false;
									}
									
									element = new Element("element");
									fieldCounter = 0;
								
											
								if(values.size() < headerLength ){
									errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has less than the required data"; 					
								}
								else if(values.size() > headerLength ){
									errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has more than the expected data"; 					
								}
								
								value = "";
								record = "";
								recBegin = currentLine + 1;
								values.clear();
								
								
							}
							else if( openQuote && !begin_field && !pre_escape ){
								value += c;
							}
							else if( openQuote && !begin_field && pre_escape ){
								openQuote = false;
								begin_field = true;
								pre_escape = false;
								
								
								if( !detectHeader ){
									
									element.addContent(new Element( fields[fieldCounter] ).setText(value));
									docj.getRootElement().addContent(element);
									}else{
										detectHeader = false;
									}
									
									element = new Element("element");
									fieldCounter = 0;
								
								
								
								values.add(value);					//Add the last value since it will not have end delimiter
								
								arrangeRecord.add(record);				//Add a record
								mapRecordtoLine.put(recordCounter, (recBegin)+" to "+(currentLine));
								recordCounter++;
											
								if(values.size() < headerLength ){
									errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has less than the required data"; 					
								}
								else if(values.size() > headerLength ){
									errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has more than the expected data"; 					
								}
								
								value = "";
								record = "";
								recBegin = currentLine + 1;
								values.clear();
								
							}
							else{
								// Unreachable stage
								JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
							}
							
							currentLine++;
							
						}
			/*			else if( c ==  space ){
							if( !openQuote && !begin_field && !pre_escape ){
								
							}
							else if( !openQuote && begin_field && !pre_escape ){
								
							}
							else if( openQuote && !begin_field && !pre_escape ){
								
							}
							else if( openQuote && !begin_field && pre_escape ){
								pre_escape = false;
								errorText +=  "\n\n"+ ++errorCounter +": UNESCAPE QUOTE:   at line " +(currentLine);
							}
							else{
								// Unreachable stage
								JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
							}
						}*/
						else if( c == quote ){
							if( !openQuote && !begin_field && !pre_escape ){
								value += c;
								errorText +=  "\n\n"+ ++errorCounter +": UNENCLOSED QUOTE: at line " +(currentLine);
								
							}
							else if( !openQuote && begin_field && !pre_escape ){
								
								openQuote = true;
								openQuotePosition =  currentLine;
								begin_field = false;
								
							}
							else if( openQuote && !begin_field && !pre_escape ){
								pre_escape = true; 
								
							}
							else if( openQuote && !begin_field && pre_escape ){
								pre_escape = false;
								value += c;
							}
							else{
								// Unreachable stage
								JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
							}
						}
						else{
							value += c;
							if( !openQuote && !begin_field && !pre_escape ){
								
							}
							else if( !openQuote && begin_field && !pre_escape ){
								
								begin_field = false; 
								
							}
							else if( openQuote && !begin_field && !pre_escape ){
								
							}
							else if( openQuote && !begin_field && pre_escape ){
								pre_escape = false;
								errorText +=  "\n\n"+ ++errorCounter +": UNESCAPE QUOTE:   at line " +(currentLine);
							}
							else{
								// Unreachable stage
								JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
							}
						}
						
					}
					
					// Add the last record since it may not have endline character
					values.add(value);
					
					
					
		//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Tokeinze the record into value			
		
					// ADD THE LAST RECORD, SINCE IT MAY NOT HAVE ENDLINE DELIMITER
					element.addContent(new Element( fields[fieldCounter] ).setText(value ));
					docj.getRootElement().addContent(element);
					element = new Element("element");
					fieldCounter = 0;
					valueItem = "";
					
					
					
					
		//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<				
				//	bufferedReader = new BufferedReader( new StringReader(editorPane.getText()) );
					
				//	String[] fields = bufferedReader.readLine().split(",");
					//for(String s: fields){ System.out.print( s ); }
					
				//	while((readLine = bufferedReader.readLine()) != null){
					//	str =  readLine.split(",");
						//for(String s: str){System.out.print(s);}
				
			//		}
					
					
					
					XMLOutputter xmlOutputter = new XMLOutputter();
					xmlOutputter.setFormat( Format.getPrettyFormat() );
					
					//  To ask for the file name rather than static file
					xmlOutputter.output(docj, new FileWriter(file.getAbsoluteFile()));
			    
			    }
			    
							
			}catch(IOException io){	
				
				System.out.print(io.getMessage());
		}
			
			
			errorDisplay.setText("\nSuccessfully exported, the following errors were detected while exporting"+errorText );
			
		
			}
			
			

			
			
			public void openFile(final JTextArea editorPane) {
				result = fileChooserObject.showOpenDialog(null); //panel or null
				
				if(result == JFileChooser.APPROVE_OPTION){
					editorPane.setText("");
					File file = fileChooserObject.getSelectedFile();
					try {
						
						System.out.print(file.getAbsolutePath()+" \nname"+file.getName());
						bufferedReader = new BufferedReader( new FileReader(file));
						while((readLine = bufferedReader.readLine()) != null){
							editorPane.append(readLine +"\n");
						}
						
						 bufferedReader.close();
						
					} catch (FileNotFoundException e) {
						JOptionPane.showMessageDialog(null, "Encouter error with saving the file\n"+e.toString(), "Errot on saving",  JOptionPane.ERROR_MESSAGE);
						e.printStackTrace();
					} catch (Exception e) {
						JOptionPane.showMessageDialog(null, "Encouter error with saving the file\n"+e.toString(), "Errot on saving",   JOptionPane.ERROR_MESSAGE);
						e.printStackTrace();
					}
					}
			}
			
			public void save(final JPanel panel, final JTextArea editorPane) {
				result = fileChooserObject.showSaveDialog(panel);
				
				if(result == JFileChooser.APPROVE_OPTION){
					File file = fileChooserObject.getSelectedFile();
					try {
						
						bufferedWriter = new BufferedWriter( new FileWriter(file));
						bufferedWriter.write(editorPane.getText());
						bufferedWriter.close();
						
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					}
			}
			
			// ADD ANOTHER DATA from different file
			public void addFile(final JTextArea editorPane) {

				result = fileChooserObject.showOpenDialog(null); 
				
				if(result == JFileChooser.APPROVE_OPTION){
					File file = fileChooserObject.getSelectedFile();
					try {
						bufferedReader = new BufferedReader( new FileReader(file));
						
						//if the file contain header remove the header
						if(  ( JOptionPane.showConfirmDialog(null, "Is the first line header ?", "Verify Header", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE)== 0 )) 
						 {	bufferedReader.readLine(); }
						
						//Start adding records in a new line
						//editorPane.append("\n");
						while((readLine = bufferedReader.readLine()) != null){
							editorPane.append(readLine +"\n");
						}
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					}
			}


			
			
			
}
