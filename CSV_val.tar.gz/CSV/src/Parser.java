import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;


public class Parser {
	
	int headerLength, recordCounter;
	JTextArea editorPane, display;
	public HashMap<Integer, String> mapRecordtoLine;
	ArrayList<String> arrangeRecord = new  ArrayList<String>();
	String  errors = "";
	
	
	//String  errortxt, warningtxt, suggestiontxt;
	
	
	Parser( JTextArea textArea  ){
		editorPane = textArea;
	}
	
	
	//Functions implementation,
	int headerSize(){
		 
		int header = 0;
		
		if(  ( JOptionPane.showConfirmDialog(null, "Is the first line header ?", "Verify Header", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE)== 0 )) 
		 {
			
			header =  editorPane.getText().split("\n")[0].split(",").length;
			
			recordCounter = 0;    								 // Data start form second line
			System.out.print(" Headersize : "+header);
		 
		 }
		else{
			 
			String noOfFields = JOptionPane.showInputDialog(editorPane, "Please how many fields are in the data ?", "Number of fields", JOptionPane.QUESTION_MESSAGE);
			
			// TO DO HERE; Detect empty   
			// Detect cancel   
			
			System.out.print(" no of fields is :"+ noOfFields);
							
			try{ header = Integer.parseInt(noOfFields); }				
			catch(NumberFormatException ex){
				
				//  To catch empty and null
				JOptionPane.showMessageDialog(editorPane, "Unrecognised input", "INPUT ERROR", JOptionPane.ERROR_MESSAGE);
				return -1;
							
				}
			recordCounter = 1;    								 // Data start from first line
		 } 
		
		return header;
		
	}
	
	public boolean validate(JTextArea editorPane,JTextArea display, JTextArea warningtxt, JTextArea suggestiontxt){
				
		if(editorPane.getText().isEmpty()){
			JOptionPane.showMessageDialog(editorPane, "The text editor has nothing to validate.", "Caution", JOptionPane.INFORMATION_MESSAGE);
			return false;
		}
		
			// Not empty
		else{
			
			headerLength = headerSize();
			if(headerLength < 0){
				JOptionPane.showMessageDialog(editorPane, " Negative is an inavalid header length.\nThe process has been terminated", "INVALID HEADER LENGHT", JOptionPane.ERROR_MESSAGE);
				return false;
			}
			
			mapRecordtoLine =  new  HashMap<Integer, String>();
			mapRecordtoLine.put(recordCounter, 1+" to "+1);										//Initialise for the first record to take care of null for firstline error
			
			parse( editorPane.getText() );
			display.setText( ">>>Errors :\n" + errors);
		}
		
		if(errors.isEmpty()){
			return true; }
		else{
			return false;		}
	}


	String[] parse( String text ){
	
		String record = "", value = "", errorText = "";
		char quote = '\"', delimiter  = ',', endLine = '\n', space = ' ';
		
		boolean pre_escape = false, openQuote = false, begin_field = true;
		
		int errorCounter = 0,  recBegin = 1, currentLine = 1, openQuotePosition = 0;
		
		ArrayList<String> values = new  ArrayList<String>();
		
		
		for( char c : text.toCharArray() ){
		
			record += c;
			value += c;
			
			
			
			if( c == delimiter ){
				if( !openQuote && !begin_field && !pre_escape ){
					begin_field = true;
					
					values.add(value);
					value = "";
				}
				else if( !openQuote && begin_field && !pre_escape ){
					values.add(value);
					value = "";
					
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					openQuote = false;
					begin_field = true;
					pre_escape = false;
					
					values.add(value);
					value = "";
										
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
					
				}
			}
			else if( c ==  endLine){
				if( !openQuote && !begin_field && !pre_escape ){
					begin_field = true;
					
					values.add(value);					//Add the last value since it will not have end delimiter
					
													
					if(values.size() < headerLength ){
						errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has less than the required data"; 					
					}
					else if(values.size() > headerLength ){
						errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has more than the expected data"; 					
					}
					
					arrangeRecord.add(record);				//Add a record
					mapRecordtoLine.put(recordCounter, (recBegin)+" to "+(currentLine));
					recordCounter++;
										
					value = "";
					record = "";
					recBegin = currentLine + 1;
					values.clear();
		
				}
				else if( !openQuote && begin_field && !pre_escape ){
					
					values.add(value);					//Add the last value since it will not have end delimiter
										
								
					if(values.size() < headerLength ){
						errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has less than the required data"; 					
					}
					else if(values.size() > headerLength ){
		
						errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has more than the expected data"; 					
					}
					
					arrangeRecord.add(record);				//Add a record
					mapRecordtoLine.put(recordCounter, (recBegin)+" to "+(currentLine));
					recordCounter++;
					
					
					value = "";
					record = "";
					recBegin = currentLine + 1;
					values.clear();
					
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					openQuote = false;
					begin_field = true;
					pre_escape = false;
					
					values.add(value);					//Add the last value since it will not have end delimiter
					
													
					if(values.size() < headerLength ){
						errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has less than the required data"; 					
					}
					else if(values.size() > headerLength ){
						errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has more than the expected data"; 					
					}
					
					arrangeRecord.add(record);				//Add a record
					mapRecordtoLine.put(recordCounter, (recBegin)+" to "+(currentLine));
					recordCounter++;
										
					value = "";
					record = "";
					recBegin = currentLine + 1;
					values.clear();
					
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
				}
				
				currentLine++;
				
			}

			else if( c == quote ){
				if( !openQuote && !begin_field && !pre_escape ){
					
					errorText +=  "\n\n"+ ++errorCounter +": UNENCLOSED QUOTE: at line " +(currentLine);
					
				}
				else if( !openQuote && begin_field && !pre_escape ){
					
					openQuote = true;
					openQuotePosition =  currentLine;
					
					begin_field = false;
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					pre_escape = true; 
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					pre_escape = false;
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
				}
			}
			else{
				if( !openQuote && !begin_field && !pre_escape ){
					
				}
				else if( !openQuote && begin_field && !pre_escape ){
					
					begin_field = false; 
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					pre_escape = false;
					errorText +=  "\n\n"+ ++errorCounter +": UNESCAPE QUOTE:   at line " +(currentLine);
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
				}
			}
			
		}
		
		
		
		
		// Add the last record since it may not have endline character
		values.add(value);
												
		
		
		if(values.size() < headerLength ){
			errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has less than the required data"; 					
		}
		else if(values.size() > headerLength ){
			errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has more than the expected data"; 					
		}
		
		if(openQuote && !pre_escape){
			errorText +=  "\n\n"+ ++errorCounter +": UNCLOSE OPEN QUOTE :  at line " +(openQuotePosition);
		}
		
		arrangeRecord.add(record);
		mapRecordtoLine.put(recordCounter, (recBegin)+" to "+(currentLine));
		recordCounter++;
			
	// Completed, assign the errors for display and return the records.	
		
		errors = errorText;
		return	 arrangeRecord.toArray(new String[arrangeRecord.size()]);
    }
	
	

	
}	
	