import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;


public class ParserwithHighlighter {
	
	int headerLength, recordCounter;
	JTextArea editorPane;
	public HashMap<Integer, String> mapRecordtoLine;
	ArrayList<String> arrangeRecord = new  ArrayList<String>();
	String  errors = "";
	final Highlighter highlighter;
	final Highlighter.HighlightPainter highlightPainter1, highlightPainter2;
	static boolean alternateColours = false;
	int index = 0;
	
	
	
	
	
	//String  errortxt, warningtxt, suggestiontxt;
	
	
	ParserwithHighlighter( JTextArea textArea  ){
			editorPane = textArea;
		 highlighter = new  DefaultHighlighter();
		 highlightPainter1 = new DefaultHighlighter.DefaultHighlightPainter(Color.yellow);
		 highlightPainter2 = new DefaultHighlighter.DefaultHighlightPainter(Color.ORANGE);
		 editorPane.setHighlighter(highlighter);
		
	}
	
	
	//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<Functions implementation,
	int headerSize(){
		 
		int header = 0;
		
		if(  ( JOptionPane.showConfirmDialog(null, "Is the first line header ?", "Verify Header", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE)== 0 )) 
		 {
			
			header =  editorPane.getText().split("\n")[0].split(",").length;
			
			recordCounter = 0;    								 // Data start form second line
			System.out.print(" Headersize : "+header);
		 
		 }
		else{
			 
			String noOfFields = JOptionPane.showInputDialog(editorPane, "Please how many fields are in the data ?", "Number of fields", JOptionPane.QUESTION_MESSAGE);
			
			// TO DO HERE; Detect empty   
			// Detect cancel   
			
			System.out.print(" no of fields is :"+ noOfFields);
							
			try{ header = Integer.parseInt(noOfFields); }				
			catch(NumberFormatException ex){
				
				//  To catch empty and null
				JOptionPane.showMessageDialog(editorPane, "Unrecognised input", "INPUT ERROR", JOptionPane.ERROR_MESSAGE);
				
							
				}
			recordCounter = 1;    								 // Data start from first line
		 } 
		
		return header;
		
	}
	
	public boolean validate(JTextArea display, JTextArea warningtxt, JTextArea suggestiontxt, HighlighterClass highlighterArg){
				
		if(editorPane.getText().isEmpty()){
			JOptionPane.showMessageDialog(editorPane, "The text editor has nothing to validate.", "Caution", JOptionPane.INFORMATION_MESSAGE);
			return false;
		}
			// Not empty
		else{
			
			headerLength = headerSize();
			if(headerLength < 0){
				JOptionPane.showMessageDialog(editorPane, " Negative is an inavalid header length.\nThe process has been terminated", "INVALID HEADER LENGHT", JOptionPane.ERROR_MESSAGE);
				return false;
			}
			mapRecordtoLine =  new  HashMap<Integer, String>();
			mapRecordtoLine.put(1, 1+" to "+1);										//Initialise for the first record to take care of null for firstline error
			
			parse( editorPane.getText(),  highlighterArg);
			display.setText( ">>>Errors :\n" + errors);
		}
		
		if(errors.isEmpty()){
			return true; }
		else{
			return false;		}
	}


	String[] parse( String text, HighlighterClass highlighterArg ){
		
		
		String record = "", value = "", errorText = "";
		char quote = '\"', delimiter  = ',', endLine = '\n', space = ' ';
		
		boolean pre_escape = false, openQuote = false, begin_field = true, detectError = false;
		
		int errorCounter = 1,  recBegin = 1, currentLine = 1, openQuotePosition = 0 , p = 0;
		
		ArrayList<String> values = new  ArrayList<String>();
		
		highlighterArg.removeHighlight();     // Remove previous highlight if it exist.
		
		
		for( char c : text.toCharArray() ){
		
			record += c;
			value += c;
			p++;
			
			if( c == delimiter ){
				if( !openQuote && !begin_field && !pre_escape ){
					begin_field = true;
					
					values.add(value);
					value = "";
				}
				else if( !openQuote && begin_field && !pre_escape ){
					values.add(value);
					value = "";
				}
				else if( openQuote && !begin_field && !pre_escape ){
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					openQuote = false;
					begin_field = true;
					pre_escape = false;
					
					values.add(value);
					value = "";
										
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
					
				}
			}
			else if( c ==  endLine){
				if( !openQuote && !begin_field && !pre_escape ){
					begin_field = true;
					
					values.add(value);					//Add the last value since it will not have end delimiter
								
					if(values.size() < headerLength ){
						errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has less than the required data";
						detectError = true;
					}
					else if(values.size() > headerLength ){
						errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has more than the expected data";
						detectError = true;
					}
					arrangeRecord.add(record);				//Add a record
					mapRecordtoLine.put(recordCounter, (recBegin)+" to "+(currentLine));
					recordCounter++;
					
					if(detectError){
						highlighterArg.highlight(record, p);
						detectError = false;
					}
					value = "";
					record = "";
					recBegin = currentLine + 1;
					values.clear();
		
				}
				else if( !openQuote && begin_field && !pre_escape ){
					
					values.add(value);					//Add the last value since it will not have end delimiter
										
								
					if(values.size() < headerLength ){
						errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has less than the required data";
						detectError = true;
					}
					else if(values.size() > headerLength ){
						errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has more than the expected data";
						detectError = true;
					}
					arrangeRecord.add(record);				//Add a record
					mapRecordtoLine.put(recordCounter, (recBegin)+" to "+(currentLine));
					recordCounter++;
					
					if(detectError){
						highlighterArg.highlight(record, p);
						detectError = false;
					}
					
					value = "";
					record = "";
					recBegin = currentLine + 1;
					values.clear();
					
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					openQuote = false;
					begin_field = true;
					pre_escape = false;
					
					values.add(value);					//Add the last value since it will not have end delimiter
											
					if(values.size() < headerLength ){
						errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has less than the required data";
						detectError = true;
					}
					else if(values.size() > headerLength ){
						errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has more than the expected data";
						detectError = true;
					}
					
					arrangeRecord.add(record);				//Add a record
					mapRecordtoLine.put(recordCounter, (recBegin)+" to "+(currentLine));
					recordCounter++;
					
					if(detectError){
						highlighterArg.highlight(record, p);
						detectError = false;
					}
					
					value = "";
					record = "";
					recBegin = currentLine + 1;
					values.clear();
					
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
				}
				
				currentLine++;
				
			}
			else if( c ==  space ){
				if( !openQuote && !begin_field && !pre_escape ){
					
				}
				else if( !openQuote && begin_field && !pre_escape ){
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					pre_escape = false;
					errorText +=  "\n\n"+ ++errorCounter +": UNESCAPE QUOTE:   at line " +(currentLine);
					detectError = true;
					
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
				}
			}
			else if( c == quote ){
				if( !openQuote && !begin_field && !pre_escape ){
					
					errorText +=  "\n\n"+ ++errorCounter +": UNENCLOSED QUOTE: at line " +(currentLine);
					detectError = true;
					
				}
				else if( !openQuote && begin_field && !pre_escape ){
					
					openQuote = true;
					openQuotePosition =  currentLine;
					
					begin_field = false;
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					pre_escape = true; 
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					pre_escape = false;
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
				}
			}
			else{
				if( !openQuote && !begin_field && !pre_escape ){
					
				}
				else if( !openQuote && begin_field && !pre_escape ){
					
					begin_field = false; 
					
				}
				else if( openQuote && !begin_field && !pre_escape ){
					
				}
				else if( openQuote && !begin_field && pre_escape ){
					pre_escape = false;
					errorText +=  "\n\n"+ ++errorCounter +": UNESCAPE QUOTE:   at line " +(currentLine);
					detectError = true;
				}
				else{
					// Unreachable stage
					JOptionPane.showMessageDialog(editorPane, "Unreachable stage", "  ERROR ", JOptionPane.ERROR_MESSAGE);
				}
			}
			
		}
		
		
		
		
		// Add the last record since it may not have endline character
		values.add(value);
												
		
	
		
		if(values.size() < headerLength ){
			errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has less than the required data"; 					
			detectError = true;
			}
		else if(values.size() > headerLength ){
			errorText += "\n\n"+ ++errorCounter+": record " +recordCounter+ " spanning line "+ (recBegin)+" to "+(currentLine) +" : has more than the expected data"; 					
			detectError = true;
			//highlight( record);
		}
		
		arrangeRecord.add(record);				//Add a record
		mapRecordtoLine.put(recordCounter, (recBegin)+" to "+(currentLine));
		recordCounter++;
		
		if(openQuote && !pre_escape ){
			errorText +=  "\n\n"+ ++errorCounter +": UNCLOSE OPEN QUOTE :  at line " +(openQuotePosition);
			detectError = true;
			//highlight(record);
		}
		if(detectError){
			highlighterArg.highlight(record, p);
			detectError = false;
		}
		
		
	// Completed, assign the errors for display and return the records.	
		
		errors = errorText;
		return	 arrangeRecord.toArray(new String[arrangeRecord.size()]);
    }
	
	
	
	/*public void highlight( String s, int pos) {
		
	//	index = editorPane.getText().indexOf(s, previousIndex);
		index = pos;
		//previousIndex = index + s.length();
		
		try {
			if(alternateColours){
				highlighter.addHighlight(index-s.length(), index,  highlightPainter1);
				//highlighter.addHighlight(index, index+s.length(), highlightPainter1);
				
				
			}
			else{
				highlighter.addHighlight(index-s.length(), index,  highlightPainter2);
				//highlighter.addHighlight(index, index+s.length(), highlightPainter2);
			}
			
			alternateColours = !alternateColours;
			
		} catch (BadLocationException e) {
			// TODO Auto-generated catch block
			
			JOptionPane.showMessageDialog(editorPane, "Error with the highlighter Location of \n : "+s+"\n"+ e.toString(), "Highlighter error", JOptionPane.INFORMATION_MESSAGE);
			
		}
	}


	public void removeHighlight(){ 

		highlighter.removeAllHighlights();
	}*/
		
}	
	