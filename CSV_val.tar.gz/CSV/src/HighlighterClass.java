import java.awt.Color;

import javax.swing.JOptionPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;


public class HighlighterClass {
	
	final  Highlighter highlighter;
	final  Highlighter.HighlightPainter highlightPainter1;
	final  Highlighter.HighlightPainter highlightPainter2;
	boolean alternateColours = true;
	
	
	
	HighlighterClass(){
	highlighter = new  DefaultHighlighter();
	highlightPainter1 = new DefaultHighlighter.DefaultHighlightPainter(Color.yellow);
	highlightPainter2 = new DefaultHighlighter.DefaultHighlightPainter(Color.ORANGE);
	
	}
	
	Highlighter getHighlighter(){
		return highlighter;
	}

	
	  void highlight( String s, int pos) {
		
	//	index = editorPane.getText().indexOf(s, previousIndex);
		
		//previousIndex = index + s.length();
		
		try {
			if(alternateColours){
				highlighter.addHighlight(pos-s.length()-1, pos,  highlightPainter1);
				//highlighter.addHighlight(index, index+s.length(), highlightPainter1);
				
			}
			else{
				highlighter.addHighlight(pos-s.length()-1, pos,  highlightPainter2);
				//highlighter.addHighlight(index, index+s.length(), highlightPainter2);
			}
			
			alternateColours = !alternateColours;
			
		} catch (BadLocationException e) {
			// TODO Auto-generated catch block
			
			JOptionPane.showMessageDialog(null, "Error with the highlighter Location of \n : "+s+"\n"+ e.toString(), "Highlighter error", JOptionPane.INFORMATION_MESSAGE);
			
		}
	}


	public  void removeHighlight(){ 
		highlighter.removeAllHighlights();
	}


}
